fx_version 'adamant'
game 'gta5'

version '1.0'

data_file 'DLC_ITYP_REQUEST' 'stream/bzzz_xmas_script_lollipop_a.ytyp'